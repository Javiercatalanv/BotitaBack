
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type ReservaDocument = Reserva & Document;

@Schema()
export class Reserva {
  @Prop({ required: true })
  nombreSocio: string;

  @Prop({ required: true })
  cancha: string;

  @Prop({ required: true })
  fechaInicio: Date;

  @Prop({ required: true })
  fechaFin: Date;

  @Prop({ default: 'pendiente' })
  estado: string;

  @Prop({
  type: [
    {
      nombre: { type: String, required: true },
      apellido: { type: String, required: true },
      rut: { type: String, required: true },
      edad: { type: Number, required: true },
    },
  ],
  required: true,
})
jugadores: {
  nombre: string;
  apellido: string;
  rut: string;
  edad: number;
}[];

}

export const ReservaSchema = SchemaFactory.createForClass(Reserva);
