
import { Controller, Get, Post, Put, Delete, Body, Param, Patch } from '@nestjs/common';
import { ReservasService } from './reservas.service';
import { Reserva } from '../schemas/reserva.schema';
import { UseGuards, Req } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';
import { Request } from 'express';

@Controller('reservas')
@UseGuards(JwtAuthGuard, RolesGuard) 
export class ReservasController {
  constructor(private readonly reservasService: ReservasService) {}

  @Post()
  create(@Body() reserva: Partial<Reserva>) {
    return this.reservasService.create(reserva);
  }

  @Roles('admin')
  @Get()
  findAll() {
    return this.reservasService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.reservasService.findOne(id);
  }

  @Put(':id')
  update(@Param('id') id: string, @Body() reserva: Partial<Reserva>) {
    return this.reservasService.update(id, reserva);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.reservasService.remove(id);
  }

  @Patch(':id/confirmar')
  confirmarReserva(@Param('id') id: string) {
    return this.reservasService.confirmarReserva(id);
  }

  @Patch(':id/cancelar')
  cancelarReserva(@Param('id') id: string) {
    return this.reservasService.cancelarReserva(id);
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('admin')
  @Get('/reportes/ingresos')
  calcularIngresos() {
    return this.reservasService.calcularIngresosTotales();
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('admin')
  @Get('/reportes/ingresos-mensuales')
  ingresosMensuales() {
    return this.reservasService.calcularIngresosMensuales();
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('admin')
  @Get('/historico')
  obtenerHistoricoAdmin() {
    return this.reservasService.obtenerHistoricoGlobal();
  }

  @UseGuards(JwtAuthGuard)
  @Get('/mis-reservas/historico')
  obtenerHistoricoUsuario(@Req() req) {
    return this.reservasService.obtenerHistoricoUsuario(req.user.userId);
  }

}

