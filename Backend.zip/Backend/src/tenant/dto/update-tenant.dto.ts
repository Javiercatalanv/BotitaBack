import { IsOptional, IsString } from 'class-validator';

export class UpdateTenantDto {
  @IsOptional()
  @IsString()
  nombreKiosco?: string;

  @IsOptional()
  @IsString()
  direccion?: string;
}
