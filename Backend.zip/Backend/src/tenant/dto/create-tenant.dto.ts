import { IsString } from 'class-validator';

export class CreateTenantDto {
  @IsString()
  nombreKiosco: string;

  @IsString()
  direccion: string;
}
