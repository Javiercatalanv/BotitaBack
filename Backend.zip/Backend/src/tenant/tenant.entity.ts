import { Entity, PrimaryGeneratedColumn, Column, OneToOne, JoinColumn } from 'typeorm';
import { User } from '../users/user.entity';

@Entity()
export class Tenant {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  nombreKiosco: string;

  @Column()
  direccion: string;

  @Column({ default: 0 })
  puntuacion: number;

  @OneToOne(() => User)
  @JoinColumn()
  usuario: User;
}

