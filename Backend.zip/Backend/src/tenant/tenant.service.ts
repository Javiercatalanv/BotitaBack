// src/tenant/tenant.service.ts
import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Tenant } from './tenant.entity';
import { CreateTenantDto } from './dto/create-tenant.dto';
import { UpdateTenantDto } from './dto/update-tenant.dto';

@Injectable()
export class TenantService {
  constructor(
    @InjectRepository(Tenant)
    private tenantRepo: Repository<Tenant>,
  ) {}

  async findByUserId(userId: number) {
  return this.tenantRepo.findOne({
    where: { usuario: { id: userId } },
    relations: ['usuario'],
  });
}


  create(dto: CreateTenantDto) {
    const tenant = this.tenantRepo.create(dto);
    return this.tenantRepo.save(tenant);
  }

  findAll() {
  return this.tenantRepo.find({ relations: ['usuario'] });
}


  async findOne(id: number) {
    const tenant = await this.tenantRepo.findOneBy({ id });
    if (!tenant) throw new NotFoundException('Locatario no encontrado');
    return tenant;
  }

  async update(id: number, dto: UpdateTenantDto) {
    await this.tenantRepo.update(id, dto);
    return this.findOne(id);
  }

  remove(id: number) {
    return this.tenantRepo.delete(id);
  }
  
}
