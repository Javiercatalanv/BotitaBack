// src/tenant/tenant.controller.ts
import { Controller, Get, UseGuards, Request, Post, Body, Param, Patch, Delete } from '@nestjs/common';
import { TenantService } from './tenant.service';
import { CreateTenantDto } from './dto/create-tenant.dto';
import { UpdateTenantDto } from './dto/update-tenant.dto';
import { JwtGuard } from '../auth/jwt.guard';
import { Roles } from '../auth/roles.decorator';
import { RolesGuard } from '../auth/roles.guard';

@Controller('tenant')
export class TenantController {
  constructor(private readonly tenantService: TenantService) {}

  @Post()
  create(@Body() dto: CreateTenantDto) {
    return this.tenantService.create(dto);
  }

  @Get()
  findAll() {
    return this.tenantService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.tenantService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() dto: UpdateTenantDto) {
    return this.tenantService.update(+id, dto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.tenantService.remove(+id);
  }

  @UseGuards(JwtGuard)
  @Get('me')
  getMyTenant(@Request() req) {
    return this.tenantService.findByUserId(req.user.userId);
  }

  @UseGuards(JwtGuard, RolesGuard)
    @Roles('admin')
    @Get('all')
    getAllTenantsAsAdmin() {
    return this.tenantService.findAll();
    }

}
