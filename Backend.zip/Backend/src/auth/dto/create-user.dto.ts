import { IsEmail, IsString } from 'class-validator';

export class CreateUserDto {
  @IsString()
  nombre: string;

  @IsEmail()
  correo: string;

  @IsString()
  contraseña: string;

  @IsString()
  tipo: string; // 'locatario' o 'admin'
}
