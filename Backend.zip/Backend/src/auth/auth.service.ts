// src/auth/auth.service.ts
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { UsersService } from '../users/users.service';

@Injectable()
export class AuthService {
  constructor(
    private usersService: UsersService,
    private jwtService: JwtService,
  ) {}

  async validateUser(correo: string, contraseña: string) {
    const user = await this.usersService.findByCorreo(correo);
    if (user && await bcrypt.compare(contraseña, user.contraseña)) {
      const { contraseña, ...result } = user;
      return result;
    }
    return null;
  }

  async login(user: any) {
    const payload = { username: user.correo, sub: user.id, tipo: user.tipo };
    return {
      access_token: this.jwtService.sign(payload),
    };
  }
}
